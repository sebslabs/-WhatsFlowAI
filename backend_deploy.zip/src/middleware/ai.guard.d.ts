/**
 * AI Hardening Middleware
 *
 * Protects the AI pipeline from:
 *  - Token budget exhaustion (per-tenant daily cap)
 *  - Prompt injection attacks
 *  - Excessive conversation history (memory limits)
 *  - API rate limit cascades
 *  - Runaway costs
 *
 * Usage (in webhook.worker.ts before getAgentResponse):
 *   const safe = await AIGuard.check(tenantId, message, history)
 *   if (!safe.allowed) { ... skip AI ... }
 *   const safeMessage = safe.sanitizedMessage
 */
export interface AIGuardResult {
    allowed: boolean;
    reason?: string;
    sanitizedMessage: string;
    truncatedHistory: {
        role: 'user' | 'assistant';
        content: string;
    }[];
}
export declare class AIGuard {
    /**
     * Run all AI safety checks before sending to any AI provider.
     */
    static check(tenantId: string, message: string, history?: {
        role: 'user' | 'assistant';
        content: string;
    }[]): Promise<AIGuardResult>;
}
//# sourceMappingURL=ai.guard.d.ts.map