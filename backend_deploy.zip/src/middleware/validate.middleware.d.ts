/**
 * Zod request validation middleware for Express.
 *
 * Usage:
 *   router.post('/leads', authenticate, validate(createLeadSchema), APIController.createLead)
 *
 * Attaches the parsed+validated body to req.body so downstream handlers
 * receive typed, safe data instead of raw untrusted input.
 */
import type { Request, Response, NextFunction } from 'express';
import type { ZodSchema } from 'zod';
export declare function validate(schema: ZodSchema): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Validates query parameters against a schema.
 * Usage: router.get('/leads', authenticate, validateQuery(paginationSchema), ...)
 */
export declare function validateQuery(schema: ZodSchema): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Validates route params (e.g. :id must be a UUID).
 */
export declare function validateParams(schema: ZodSchema): (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=validate.middleware.d.ts.map