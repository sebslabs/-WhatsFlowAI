/**
 * Auth Middleware — Fixed
 *
 * CHANGES:
 * - organizationId renamed to tenantId in req.user
 * - Reads tenant_id from tenant_members (not organization_id from profiles)
 * - Profiles.organization_id kept as fallback for backward compat (it maps to tenant_id)
 */
import type { Request, Response, NextFunction } from 'express';
declare global {
    namespace Express {
        interface Request {
            user?: {
                id: string;
                email: string;
                role: 'admin' | 'agent' | 'viewer' | 'user';
                /** Canonical tenant UUID — ALWAYS use this, never organization_id */
                tenantId: string;
                /** @deprecated use tenantId — kept for controllers that haven't migrated yet */
                organizationId: string;
            };
        }
    }
}
export declare function authenticate(req: Request, res: Response, next: NextFunction): Promise<void>;
export declare function requireAdmin(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=auth.middleware.d.ts.map