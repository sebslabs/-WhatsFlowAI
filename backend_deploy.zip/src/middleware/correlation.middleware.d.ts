/**
 * Correlation ID Middleware
 *
 * Attaches a unique correlation ID to every incoming HTTP request.
 * The ID is propagated through async context so all logs from the same
 * request automatically include it — no passing needed.
 *
 * Header: X-Correlation-Id (read from request if present, otherwise generated)
 * Response: X-Correlation-Id is echoed back for client-side debugging
 */
import type { Request, Response, NextFunction } from 'express';
export declare function correlationMiddleware(req: Request, res: Response, next: NextFunction): void;
/**
 * Request latency logging middleware.
 * Logs response time on finish.
 */
export declare function latencyMiddleware(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=correlation.middleware.d.ts.map