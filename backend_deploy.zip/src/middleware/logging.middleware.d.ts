import type { Request, Response, NextFunction } from 'express';
export declare function apiLoggingMiddleware(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=logging.middleware.d.ts.map