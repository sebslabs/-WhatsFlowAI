/**
 * Upstash Redis rate limiter middleware for Express.
 *
 * Install: npm i @upstash/redis @upstash/ratelimit
 * Set env: UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN
 */
import type { Request, Response, NextFunction } from 'express';
/** 120 requests / 60s per authenticated user */
export declare const apiRateLimit: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/** 10 requests / 60s for auth endpoints */
export declare const authRateLimit: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/** 30 AI calls / 60s per user (controls OpenAI spend) */
export declare const aiRateLimit: (req: Request, res: Response, next: NextFunction) => Promise<void>;
/** 300 webhook events / 60s per IP */
export declare const webhookRateLimit: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=rate-limit.middleware.d.ts.map