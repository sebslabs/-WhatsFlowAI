/**
 * Tenant Middleware — Fixed
 *
 * CHANGES:
 * - injectTenantId now injects tenant_id (not organization_id) into req.body
 * - Strips both organization_id and user_id from client payloads
 */
import type { Request, Response, NextFunction } from 'express';
import { SupabaseClient } from '@supabase/supabase-js';
declare global {
    namespace Express {
        interface Request {
            tenantDb?: SupabaseClient;
            adminDb?: SupabaseClient;
        }
    }
}
/**
 * Attaches a user-JWT-scoped Supabase client (RLS active) to req.tenantDb.
 * Must run after authenticate().
 */
export declare function attachTenantDb(req: Request, res: Response, next: NextFunction): void;
/**
 * Service-role client — only for privileged internal operations.
 * NEVER expose to client-facing routes.
 */
export declare function attachAdminDb(req: Request, _res: Response, next: NextFunction): void;
/**
 * Injects the authenticated user's tenant_id into req.body.
 * Prevents client-supplied tenant_id or organization_id overrides.
 * Must run after authenticate().
 */
export declare function injectTenantId(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=tenant.middleware.d.ts.map