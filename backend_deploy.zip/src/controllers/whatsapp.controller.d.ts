/**
 * WhatsApp Controller — Fixed
 *
 * Changes vs previous version:
 *  - whatsapp_integrations → whatsapp_accounts (correct table name)
 *  - user.organizationId → user.tenantId (canonical)
 *  - encrypt() from utils/encryption.ts (AES-256-GCM, not the old crypto.js)
 *  - verifyToken() via WhatsAppService before storing credentials
 *  - Delivery status webhook updates routed to handleDeliveryStatusUpdate()
 *  - console.log/error → logger
 */
import type { Request, Response } from 'express';
export declare class WhatsAppController {
    /**
     * POST /api/whatsapp/connect
     * Stores encrypted credentials and verifies them with Meta.
     */
    static connect(req: Request, res: Response): Promise<void>;
    /**
     * GET /api/whatsapp/config
     * Returns the current WhatsApp account configuration for the tenant.
     */
    static getConfig(req: Request, res: Response): Promise<void>;
    /**
     * GET /api/whatsapp/verify
     * Meta webhook challenge verification (must be public, no auth).
     */
    static verify(req: Request, res: Response): Promise<void>;
    /**
     * POST /api/whatsapp/webhook
     * Receives inbound messages + delivery status updates from Meta.
     * Must respond 200 within 5s — all processing is async.
     */
    static webhook(req: Request, res: Response): Promise<void>;
    /**
     * POST /api/whatsapp/send
     * Manual agent send — sends a message from the inbox UI.
     */
    static send(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=whatsapp.controller.d.ts.map