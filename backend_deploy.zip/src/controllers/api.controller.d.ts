import type { Request, Response } from 'express';
export declare class APIController {
    private static tenantDb;
    private static tenantId;
    /** @deprecated use tenantId() */
    private static orgId;
    static getConversations(req: Request, res: Response): Promise<void>;
    static getMessages(req: Request, res: Response): Promise<void>;
    static getStats(req: Request, res: Response): Promise<void>;
    static getLeads(req: Request, res: Response): Promise<void>;
    static getFlows(req: Request, res: Response): Promise<void>;
    static getCampaigns(req: Request, res: Response): Promise<void>;
    static saveCampaign(req: Request, res: Response): Promise<void>;
    static deleteCampaign(req: Request, res: Response): Promise<void>;
    static getKnowledgeSources(req: Request, res: Response): Promise<void>;
    static getAnalytics(req: Request, res: Response): Promise<void>;
    /** tickets table doesn't exist in production schema — mapped to handoff_requests */
    static getTickets(req: Request, res: Response): Promise<void>;
    static createTicket(req: Request, res: Response): Promise<void>;
    static saveFlow(req: Request, res: Response): Promise<void>;
    static deleteFlow(req: Request, res: Response): Promise<void>;
    static getSettings(req: Request, res: Response): Promise<void>;
    static updateSettings(req: Request, res: Response): Promise<void>;
    static getWhatsAppTemplates(req: Request, res: Response): Promise<void>;
    static saveWhatsAppTemplate(req: Request, res: Response): Promise<void>;
    static deleteWhatsAppTemplate(req: Request, res: Response): Promise<void>;
    static uploadCatalogImage(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static getCatalogProducts(req: Request, res: Response): Promise<void>;
    static createCatalogProduct(req: Request, res: Response): Promise<void>;
    static updateCatalogProduct(req: Request, res: Response): Promise<void>;
    static deleteCatalogProduct(req: Request, res: Response): Promise<void>;
    static getAIAgents(req: Request, res: Response): Promise<void>;
    static createAIAgent(req: Request, res: Response): Promise<void>;
    static updateAIAgent(req: Request, res: Response): Promise<void>;
    static deleteAIAgent(req: Request, res: Response): Promise<void>;
    static toggleAIAgentStatus(req: Request, res: Response): Promise<void>;
    static chatWithAIAgent(req: Request, res: Response): Promise<void>;
    static chatPublicBot(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=api.controller.d.ts.map