import type { Request, Response } from 'express';
export declare class LogsController {
    /**
     * Retrieve user/tenant specific API logs with simple filters.
     * GET /api/logs
     */
    static getLogs(req: Request, res: Response): Promise<void>;
    /**
     * Retrieve specific log detail.
     * GET /api/logs/:id
     */
    static getLogById(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=logs.controller.d.ts.map