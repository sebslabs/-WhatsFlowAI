/**
 * WhatsApp webhook controller.
 *
 * GET  /webhook — Meta's one-time verification handshake
 * POST /webhook — Incoming messages (signature-verified, then enqueued)
 *
 * CRITICAL: Do NOT process messages synchronously here.
 * Meta requires a 200 within 5 s or it retries → duplicate messages.
 * We verify the signature, enqueue the job, and return 200 immediately.
 * The webhook.worker.ts process handles AI and DB writes asynchronously.
 */
import type { Request, Response } from 'express';
export declare class WebhookController {
    /** Meta webhook verification handshake */
    static verify(req: Request, res: Response): void;
    /** Incoming message handler — verify → enqueue → 200 */
    static handle(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=webhook.controller.d.ts.map