import type { Request } from 'express';
import { type SupabaseClient } from '@supabase/supabase-js';
/**
 * Supabase client scoped to the caller's JWT — RLS policies apply.
 * Never use the service-role client for user-facing CRUD.
 */
export declare function createTenantSupabaseClient(req: Request): SupabaseClient;
//# sourceMappingURL=supabase-tenant.d.ts.map