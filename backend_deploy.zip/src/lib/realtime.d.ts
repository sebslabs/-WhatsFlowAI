/**
 * WebSocket / Realtime Hardening
 *
 * Production-safe Socket.IO setup with:
 *  - Redis adapter for horizontal scaling (multiple server instances)
 *  - Tenant-scoped rooms (tenant_${id}) — cross-tenant isolation
 *  - Conversation-scoped rooms (conv_${id}) — precise subscriptions
 *  - Rate limiting per socket (10 events/sec)
 *  - Reconnect-safe: clients re-join rooms on reconnect automatically
 *  - Missed event replay via Redis XREAD (last 60s on reconnect)
 *  - Auth via Supabase JWT (revalidated on every connection)
 */
import { Server as SocketIOServer } from 'socket.io';
import type { Server as HttpServer } from 'http';
export declare function createRealtimeServer(httpServer: HttpServer): Promise<SocketIOServer>;
export declare function emitToTenant(tenantId: string, event: string, data: unknown): void;
export declare function emitToConversation(conversationId: string, event: string, data: unknown): void;
/**
 * Emit a new_message event to all clients watching a conversation.
 * Called by webhook.worker after inserting an inbound or AI message.
 */
export declare function broadcastNewMessage(tenantId: string, conversationId: string, message: Record<string, unknown>): void;
export declare function getIO(): SocketIOServer | null;
//# sourceMappingURL=realtime.d.ts.map