/**
 * Startup Validator
 *
 * Runs BEFORE the HTTP server binds. Validates:
 *  - Required environment variables
 *  - Database connectivity + schema readiness
 *  - Redis connectivity
 *  - Encryption key format
 *  - Supabase table existence
 *
 * If any check fails → process.exit(1) with a clear error.
 * This guarantees the server never starts in a broken state.
 */
export declare function validateStartup(): Promise<void>;
//# sourceMappingURL=startup.validator.d.ts.map