/**
 * Circuit Breaker
 *
 * Implements the classic circuit breaker pattern for external APIs:
 *  - Meta Cloud API
 *  - Gemini / Groq / OpenAI / OpenRouter
 *  - Supabase (for write operations under extreme load)
 *
 * States:
 *  CLOSED   → normal operation, calls pass through
 *  OPEN     → too many failures, calls fail fast (no network hit)
 *  HALF_OPEN → test mode, one probe call allowed
 *
 * Benefits:
 *  - Prevents thundering herd on failing external services
 *  - Gives providers time to recover
 *  - Protects BullMQ retry budget from being exhausted instantly
 *  - Provides fast failure instead of 15s timeout storms
 */
import { logger } from './logger.js';
export class CircuitBreaker {
    state = 'CLOSED';
    failureCount = 0;
    successCount = 0;
    lastFailureTime = 0;
    opts;
    constructor(opts) {
        this.opts = { successThreshold: 1, ...opts };
    }
    get currentState() { return this.state; }
    onSuccess() {
        this.failureCount = 0;
        if (this.state === 'HALF_OPEN') {
            this.successCount++;
            if (this.successCount >= this.opts.successThreshold) {
                this.state = 'CLOSED';
                this.successCount = 0;
                logger.info(`[circuit:${this.opts.name}] Circuit CLOSED (recovered)`);
            }
        }
    }
    onFailure(err) {
        this.failureCount++;
        this.lastFailureTime = Date.now();
        if (this.state === 'HALF_OPEN') {
            this.state = 'OPEN';
            this.successCount = 0;
            logger.warn(`[circuit:${this.opts.name}] HALF_OPEN probe failed → OPEN again`);
            return;
        }
        if (this.failureCount >= this.opts.failureThreshold) {
            this.state = 'OPEN';
            logger.error(`[circuit:${this.opts.name}] Circuit OPENED after ${this.failureCount} failures`, {
                lastError: err.message,
            });
        }
    }
    /**
     * Execute a function protected by the circuit breaker.
     * Throws CircuitOpenError if the circuit is OPEN.
     */
    async execute(fn) {
        if (this.state === 'OPEN') {
            const elapsed = Date.now() - this.lastFailureTime;
            if (elapsed >= this.opts.recoveryTimeoutMs) {
                this.state = 'HALF_OPEN';
                this.successCount = 0;
                logger.info(`[circuit:${this.opts.name}] Circuit HALF_OPEN (probing)`);
            }
            else {
                const waitSec = ((this.opts.recoveryTimeoutMs - elapsed) / 1000).toFixed(0);
                throw new CircuitOpenError(`Circuit breaker OPEN for '${this.opts.name}'. Retry in ${waitSec}s.`);
            }
        }
        try {
            const result = await fn();
            this.onSuccess();
            return result;
        }
        catch (err) {
            this.onFailure(err instanceof Error ? err : new Error(String(err)));
            throw err;
        }
    }
    /** Reset the circuit to CLOSED (for testing or manual intervention) */
    reset() {
        this.state = 'CLOSED';
        this.failureCount = 0;
        this.successCount = 0;
        logger.info(`[circuit:${this.opts.name}] Circuit manually reset to CLOSED`);
    }
    stats() {
        return {
            name: this.opts.name,
            state: this.state,
            failures: this.failureCount,
            lastFailure: this.lastFailureTime
                ? new Date(this.lastFailureTime).toISOString()
                : null,
        };
    }
}
export class CircuitOpenError extends Error {
    code = 'CIRCUIT_OPEN';
    constructor(message) {
        super(message);
        this.name = 'CircuitOpenError';
    }
}
// ── Pre-configured Breakers (singleton) ──────────────────────────────────────
export const breakers = {
    metaApi: new CircuitBreaker({
        name: 'meta-cloud-api',
        failureThreshold: 5,
        recoveryTimeoutMs: 60_000, // 1 minute
        successThreshold: 2,
    }),
    gemini: new CircuitBreaker({
        name: 'gemini',
        failureThreshold: 3,
        recoveryTimeoutMs: 30_000, // 30 seconds
    }),
    groq: new CircuitBreaker({
        name: 'groq',
        failureThreshold: 3,
        recoveryTimeoutMs: 30_000,
    }),
    openai: new CircuitBreaker({
        name: 'openai',
        failureThreshold: 3,
        recoveryTimeoutMs: 60_000,
    }),
    openrouter: new CircuitBreaker({
        name: 'openrouter',
        failureThreshold: 3,
        recoveryTimeoutMs: 30_000,
    }),
};
/** Get all circuit breaker stats for /metrics endpoint */
export function getAllCircuitStats() {
    return Object.values(breakers).map((b) => b.stats());
}
//# sourceMappingURL=circuit-breaker.js.map