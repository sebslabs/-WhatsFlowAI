/**
 * Prometheus Metrics Service
 *
 * Exposes metrics at GET /metrics (Prometheus text format)
 * Compatible with Grafana + Prometheus scraping.
 *
 * Tracks:
 *  - HTTP request duration by route + status
 *  - Queue depth per queue name
 *  - AI requests by provider + outcome
 *  - WhatsApp send success/failure rate
 *  - Circuit breaker state per service
 *  - Active WebSocket connections
 *  - DB query latency (manual instrumentation)
 *
 * Zero external deps — hand-rolled Prometheus format.
 * Drop-in replacement when you add prom-client later.
 */
export declare const metrics: {
    /** Increment a counter */
    inc(name: string, labels?: Record<string, string>, value?: number): void;
    /** Set a gauge */
    set(name: string, value: number, labels?: Record<string, string>): void;
    /** Record a duration in ms to a histogram */
    observe(name: string, ms: number, labels?: Record<string, string>, buckets?: number[]): void;
    /** Time an async function and record result */
    timed<T>(name: string, fn: () => Promise<T>, labels?: Record<string, string>): Promise<T>;
};
export declare function renderPrometheusMetrics(): string;
export declare const METRICS: {
    readonly HTTP_REQUEST_DURATION: "http_request_duration_ms";
    readonly HTTP_REQUESTS_TOTAL: "http_requests_total";
    readonly QUEUE_DEPTH: "bullmq_queue_depth";
    readonly QUEUE_PROCESSED: "bullmq_jobs_processed_total";
    readonly QUEUE_FAILED: "bullmq_jobs_failed_total";
    readonly QUEUE_DLQ_SIZE: "bullmq_dlq_size";
    readonly WA_SEND_TOTAL: "whatsapp_send_total";
    readonly WA_SEND_LATENCY: "whatsapp_send_latency_ms";
    readonly AI_REQUESTS_TOTAL: "ai_requests_total";
    readonly AI_LATENCY: "ai_request_latency_ms";
    readonly AI_TOKENS_USED: "ai_tokens_used_total";
    readonly CB_STATE: "circuit_breaker_state";
    readonly CB_FAILURES: "circuit_breaker_failures_total";
    readonly WS_CONNECTIONS: "websocket_connections_active";
    readonly DB_QUERY_LATENCY: "db_query_latency_ms";
};
export declare function metricsHandler(): (_req: unknown, res: {
    setHeader: Function;
    end: Function;
}) => void;
export declare function startQueueMetricsCollection(): void;
export declare function stopQueueMetricsCollection(): void;
//# sourceMappingURL=metrics.d.ts.map