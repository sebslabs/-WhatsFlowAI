/** Strips HTML tags and unsafe characters from user input on the server. */
export declare function stripTags(input: string): string;
export declare function sanitizeMessage(raw: string): string;
//# sourceMappingURL=sanitize.d.ts.map