/**
 * Logger Service — Structured, Correlation-ID–aware
 *
 * Every log line is a JSON object containing:
 *   - level, message, timestamp
 *   - correlationId (propagated through async context via AsyncLocalStorage)
 *   - tenantId, userId when available
 *   - arbitrary metadata fields
 *
 * Usage:
 *   import { logger } from '../utils/logger.js'
 *   logger.info('Webhook processed', { tenantId, messageId, latencyMs })
 *   logger.error('Worker failed', { jobId, err })
 */
import { AsyncLocalStorage } from 'async_hooks';
export interface LogContext {
    correlationId?: string;
    tenantId?: string;
    userId?: string;
    jobId?: string;
    traceId?: string;
}
export declare const logStorage: AsyncLocalStorage<LogContext>;
export declare const logger: {
    debug: (msg: string, meta?: Record<string, unknown>) => void;
    info: (msg: string, meta?: Record<string, unknown>) => void;
    warn: (msg: string, meta?: Record<string, unknown>) => void;
    error: (msg: string, meta?: Record<string, unknown>) => void;
    /** Run a function with an established log context (correlationId, tenantId, etc.) */
    withContext<T>(ctx: LogContext, fn: () => T): T;
    /** Measure and log execution time of an async operation */
    timed<T>(label: string, fn: () => Promise<T>, meta?: Record<string, unknown>): Promise<T>;
};
export declare function generateCorrelationId(): string;
//# sourceMappingURL=logger.d.ts.map