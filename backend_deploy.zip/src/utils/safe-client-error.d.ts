import type { Response } from 'express';
/**
 * Avoid leaking PostgREST / DB internals to API clients in production.
 */
export declare function sendSafeError(res: Response, err: unknown, statusCode?: number): void;
//# sourceMappingURL=safe-client-error.d.ts.map