/**
 * Sentry Integration
 *
 * Centralizes all Sentry setup in one file.
 * Call initSentry() at the top of index.ts before anything else.
 *
 * Includes:
 *  - Error capture with tenant context
 *  - Correlation ID in Sentry breadcrumbs
 *  - Performance monitoring (if DSN is set)
 *  - BullMQ job failure reporting
 *  - Circuit breaker OPEN state alerts
 *  - Manual error reporting with extra context
 *
 * Gracefully degrades if SENTRY_DSN is not set
 * (all functions become no-ops in development).
 */
export declare function initSentry(): Promise<void>;
export declare function captureError(err: Error, context?: {
    tenantId?: string | undefined;
    correlationId?: string | undefined;
    jobId?: string | undefined;
    [key: string]: unknown;
}): Promise<void>;
export declare function captureQueueFailure(jobId: string | undefined, queueName: string, err: Error, jobData: unknown): Promise<void>;
export declare function captureCircuitOpen(serviceName: string): Promise<void>;
export declare function sentryErrorHandler(): Promise<any>;
export declare function sentryRequestHandler(): Promise<any>;
//# sourceMappingURL=sentry.d.ts.map