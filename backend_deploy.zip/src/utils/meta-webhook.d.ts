/**
 * Extract Meta Cloud API phone_number_id from a WhatsApp webhook JSON payload.
 */
export declare function extractPhoneNumberIdFromMetaPayload(payload: Record<string, unknown>): string | null;
//# sourceMappingURL=meta-webhook.d.ts.map