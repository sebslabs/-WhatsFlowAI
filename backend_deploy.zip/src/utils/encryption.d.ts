/**
 * Encryption Helpers — pgcrypto-compatible AES-256-GCM
 *
 * Used to encrypt sensitive data (WhatsApp tokens, webhook secrets, API keys)
 * BEFORE inserting into PostgreSQL.
 *
 * Strategy:
 *  - AES-256-GCM via Node.js crypto (no extra deps)
 *  - Random 12-byte IV per encryption
 *  - Authentication tag prevents tampering
 *  - Output: base64("iv:authTag:ciphertext") — all three parts needed to decrypt
 *
 * Key Management:
 *  - ENCRYPTION_KEY must be 32 bytes hex (64 hex chars) in env
 *  - Rotate by decrypting old data with old key, re-encrypting with new key
 *  - NEVER store the key in the database
 *
 * Usage:
 *   const encrypted = encrypt(access_token)
 *   await db.from('whatsapp_accounts').update({ access_token: encrypted })
 *
 *   const plaintext = decrypt(row.access_token)
 */
/**
 * Encrypt a plaintext string.
 * Returns a base64-encoded payload containing iv:authTag:ciphertext.
 * Returns null if value is null/undefined (preserves DB nullability).
 */
export declare function encrypt(value: string | null | undefined): string | null;
/**
 * Decrypt an encrypted payload produced by encrypt().
 * Returns null if value is null/undefined (preserves DB nullability).
 * Throws on tampered/corrupt data (GCM auth tag mismatch).
 */
export declare function decrypt(value: string | null | undefined): string | null;
/**
 * Hash a value with SHA-256 for non-reversible lookup (e.g., api_keys.key_hash).
 * Returns hex string.
 */
export declare function hashForLookup(value: string): string;
/**
 * Generate a secure random API key with prefix.
 * Returns: { plaintext: 'wf_...', hash: '...', prefix: 'wf_xxxx' }
 * Store ONLY hash and prefix. NEVER store the plaintext.
 */
export declare function generateApiKey(): {
    plaintext: string;
    hash: string;
    prefix: string;
};
/**
 * Safely compare two strings in constant time (prevent timing attacks).
 */
export declare function safeCompare(a: string, b: string): boolean;
//# sourceMappingURL=encryption.d.ts.map