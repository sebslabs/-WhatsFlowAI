import type { Request } from 'express';
/**
 * Extract Supabase JWT from Authorization header or sb-access-token cookie.
 * Must match auth.middleware token extraction for consistent tenant scoping.
 */
export declare function extractAccessToken(req: Request): string | null;
//# sourceMappingURL=auth-token.d.ts.map