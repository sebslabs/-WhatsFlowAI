/**
 * Circuit Breaker
 *
 * Implements the classic circuit breaker pattern for external APIs:
 *  - Meta Cloud API
 *  - Gemini / Groq / OpenAI / OpenRouter
 *  - Supabase (for write operations under extreme load)
 *
 * States:
 *  CLOSED   → normal operation, calls pass through
 *  OPEN     → too many failures, calls fail fast (no network hit)
 *  HALF_OPEN → test mode, one probe call allowed
 *
 * Benefits:
 *  - Prevents thundering herd on failing external services
 *  - Gives providers time to recover
 *  - Protects BullMQ retry budget from being exhausted instantly
 *  - Provides fast failure instead of 15s timeout storms
 */
export type CBState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';
export interface CircuitBreakerOptions {
    /** Number of consecutive failures before opening the circuit */
    failureThreshold: number;
    /** Milliseconds the circuit stays OPEN before probing */
    recoveryTimeoutMs: number;
    /** Optional success threshold in HALF_OPEN before re-closing */
    successThreshold?: number;
    /** Name for logging/metrics */
    name: string;
}
export declare class CircuitBreaker {
    private state;
    private failureCount;
    private successCount;
    private lastFailureTime;
    private readonly opts;
    constructor(opts: CircuitBreakerOptions);
    get currentState(): CBState;
    private onSuccess;
    private onFailure;
    /**
     * Execute a function protected by the circuit breaker.
     * Throws CircuitOpenError if the circuit is OPEN.
     */
    execute<T>(fn: () => Promise<T>): Promise<T>;
    /** Reset the circuit to CLOSED (for testing or manual intervention) */
    reset(): void;
    stats(): {
        name: string;
        state: CBState;
        failures: number;
        lastFailure: string | null;
    };
}
export declare class CircuitOpenError extends Error {
    readonly code = "CIRCUIT_OPEN";
    constructor(message: string);
}
export declare const breakers: {
    metaApi: CircuitBreaker;
    gemini: CircuitBreaker;
    groq: CircuitBreaker;
    openai: CircuitBreaker;
    openrouter: CircuitBreaker;
};
/** Get all circuit breaker stats for /metrics endpoint */
export declare function getAllCircuitStats(): {
    name: string;
    state: CBState;
    failures: number;
    lastFailure: string | null;
}[];
//# sourceMappingURL=circuit-breaker.d.ts.map