/**
 * Webhook message queue using BullMQ + Redis.
 *
 * Why queues are mandatory for WhatsApp webhooks:
 *   1. Meta requires a 200 response within 5 seconds or it retries.
 *   2. AI inference (OpenAI/Gemini) can take 3-15 seconds.
 *   3. A slow DB or AI call would cause Meta to retry → duplicate messages.
 *   4. Queues provide retry logic, backpressure, and dead-letter handling.
 *
 * Flow:
 *   Webhook POST → validate signature → enqueue job → return 200 immediately
 *   Worker (separate process) → dequeue → process AI → write to DB → send reply
 *
 * Install: npm i bullmq ioredis
 * Set env: REDIS_URL (e.g. redis://localhost:6379 or Upstash TLS URL)
 */
import { Queue } from 'bullmq';
import { Redis } from 'ioredis';
const QUEUE_NAME = 'whatsapp-messages';
function createRedisConnection() {
    const url = process.env.REDIS_URL ?? 'redis://localhost:6379';
    return new Redis(url, {
        maxRetriesPerRequest: null, // Required by BullMQ
        enableReadyCheck: false,
        tls: url.startsWith('rediss://') ? {} : undefined,
    });
}
let _queue = null;
export function getMessageQueue() {
    if (_queue)
        return _queue;
    const connection = createRedisConnection();
    const opts = {
        connection,
        defaultJobOptions: {
            attempts: 5,
            backoff: {
                type: 'exponential',
                delay: 2000, // Start at 2s, double each retry: 2s, 4s, 8s, 16s, 32s
            },
            removeOnComplete: { count: 1000 },
            removeOnFail: { count: 500 },
        },
    };
    _queue = new Queue(QUEUE_NAME, opts);
    return _queue;
}
/**
 * Enqueue an incoming WhatsApp message for async processing.
 * Call this from the webhook handler — do NOT process inline.
 */
export async function enqueueWebhookMessage(data) {
    const queue = getMessageQueue();
    const job = await queue.add('process-message', data, {
        // Use Meta's message ID as the job ID for natural deduplication
        jobId: data.messageId,
        // Deduplicate: if the same messageId arrives twice, BullMQ silently skips
        // This prevents double-processing when Meta retries after a slow response
    });
    return job.id;
}
export { QUEUE_NAME };
//# sourceMappingURL=queue.service.js.map