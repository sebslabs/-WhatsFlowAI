export declare class AIService {
    /**
     * Get response from OpenAI
     */
    static getOpenAIResponse(prompt: string, context?: string): Promise<string>;
    /**
     * Get response from Gemini
     */
    static getGeminiResponse(prompt: string, context?: string): Promise<string>;
    /**
     * Get response from Groq (Ultra Fast)
     */
    static getGroqResponse(prompt: string, context?: string, model?: string): Promise<string>;
    /**
     * Get response from OpenRouter
     */
    static getOpenRouterResponse(prompt: string, context?: string, model?: string): Promise<string>;
    /**
     * Helper to map frontend model IDs to OpenRouter standard IDs
     */
    private static mapToOpenRouterModel;
    /**
     * Get a response from an AI agent persona (with conversation history).
     * Production-hardened: timeout, structured logging, provider fallback chain.
     */
    static getAgentResponse(message: string, systemPrompt: string, history?: {
        role: 'user' | 'assistant';
        content: string;
    }[], modelStr?: string): Promise<string>;
    /**
     * Analyze conversation history to determine the appropriate Lead Stage automatically.
     * Helps move leads through the pipeline (New -> Contacted -> Qualifying -> ... -> Booked)
     */
    static evaluateLeadStage(history: {
        role: 'user' | 'assistant';
        content: string;
    }[], currentStage: string): Promise<string | null>;
    /**
     * Generate embeddings for RAG (using OpenAI)
     */
    static generateEmbeddings(text: string): Promise<number[]>;
}
//# sourceMappingURL=ai.service.d.ts.map