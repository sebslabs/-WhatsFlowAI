/**
 * Webhook message queue using BullMQ + Redis.
 *
 * Why queues are mandatory for WhatsApp webhooks:
 *   1. Meta requires a 200 response within 5 seconds or it retries.
 *   2. AI inference (OpenAI/Gemini) can take 3-15 seconds.
 *   3. A slow DB or AI call would cause Meta to retry → duplicate messages.
 *   4. Queues provide retry logic, backpressure, and dead-letter handling.
 *
 * Flow:
 *   Webhook POST → validate signature → enqueue job → return 200 immediately
 *   Worker (separate process) → dequeue → process AI → write to DB → send reply
 *
 * Install: npm i bullmq ioredis
 * Set env: REDIS_URL (e.g. redis://localhost:6379 or Upstash TLS URL)
 */
import { Queue } from 'bullmq';
export interface WebhookJobData {
    /** Unique message ID from Meta (for deduplication + webhook_events idempotency) */
    messageId: string;
    /** WhatsApp sender phone number (E.164 format) */
    from: string;
    /** Message text content */
    text: string;
    /** ISO timestamp from Meta */
    timestamp: string;
    /** Meta phone_number_id — resolves tenant from whatsapp_accounts table */
    phoneNumberId: string | null;
    /** Pre-resolved tenant UUID (short-circuit if known) */
    tenantId?: string;
    /** Raw Meta payload for audit/debug */
    rawPayload: Record<string, unknown>;
}
declare const QUEUE_NAME = "whatsapp-messages";
export declare function getMessageQueue(): Queue<WebhookJobData>;
/**
 * Enqueue an incoming WhatsApp message for async processing.
 * Call this from the webhook handler — do NOT process inline.
 */
export declare function enqueueWebhookMessage(data: WebhookJobData): Promise<string>;
export { QUEUE_NAME };
//# sourceMappingURL=queue.service.d.ts.map