/**
 * WhatsApp Cloud API Service
 *
 * The ONLY file that calls the Meta Graph API.
 * All outbound message sends go through this service.
 *
 * Supports:
 *  - Text messages
 *  - Template messages
 *  - Media messages (image, document, video)
 *  - Mark as read (delivery reconciliation)
 *
 * All sends are idempotent — Meta uses message IDs for dedup on their side.
 * On our side, outbound_messages.idempotency_key prevents double sends on retry.
 */
export interface TextMessage {
    type: 'text';
    body: string;
}
export interface TemplateMessage {
    type: 'template';
    templateName: string;
    languageCode: string;
    components?: unknown[];
}
export interface MediaMessage {
    type: 'image' | 'document' | 'video' | 'audio';
    mediaUrl: string;
    caption?: string;
    filename?: string;
}
export type OutboundPayload = TextMessage | TemplateMessage | MediaMessage;
export interface SendResult {
    success: boolean;
    waMessageId?: string | undefined;
    error?: string | undefined;
    statusCode?: number | undefined;
}
/** Invalidate the token cache for a tenant (call after token rotation) */
export declare function invalidateAccountCache(tenantId: string): void;
export declare class WhatsAppService {
    /**
     * Send a text message to a WhatsApp number.
     * @param tenantId   Tenant UUID (used to look up the WhatsApp account)
     * @param toPhone    Recipient E.164 phone number (e.g. "14155238886")
     * @param text       Message body (max 4096 chars)
     */
    static sendText(tenantId: string, toPhone: string, text: string): Promise<SendResult>;
    /**
     * Send a WhatsApp Approved Template message.
     */
    static sendTemplate(tenantId: string, toPhone: string, templateName: string, languageCode: string, components?: unknown[]): Promise<SendResult>;
    /**
     * Send a media message (image, document, video, audio).
     * mediaUrl must be a public HTTPS URL accessible by Meta.
     */
    static sendMedia(tenantId: string, toPhone: string, mediaType: 'image' | 'document' | 'video' | 'audio', mediaUrl: string, caption?: string, filename?: string): Promise<SendResult>;
    /**
     * Mark a received message as read (improves user experience — shows blue ticks).
     */
    static markAsRead(tenantId: string, waMessageId: string): Promise<void>;
    /**
     * Verify that a token is valid by calling the Graph API /me endpoint.
     * Used during WhatsApp account connection flow.
     */
    static verifyToken(accessToken: string): Promise<boolean>;
}
//# sourceMappingURL=whatsapp.service.d.ts.map