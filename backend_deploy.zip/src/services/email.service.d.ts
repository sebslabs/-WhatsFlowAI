export declare class EmailService {
    private static NOTIFICATION_EMAIL;
    static sendTicketAlert(ticket: {
        title: string;
        description?: string;
        priority?: string;
        id: string;
    }, userEmail?: string): Promise<unknown>;
}
//# sourceMappingURL=email.service.d.ts.map