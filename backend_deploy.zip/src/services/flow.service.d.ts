/**
 * Flow Service — Unified Flow Engine
 *
 * Consolidated from the old `flows` + `chatbot_flows` split.
 * Now reads exclusively from `chatbot_flows` with `tenant_id` scope.
 * Tracks state in `leads.current_flow_id` + `leads.current_step_index`.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
export declare class FlowService {
    /**
     * Execute the next step of a flow.
     * @param db         Service-role Supabase client
     * @param tenantId   Tenant UUID (NOT organization_id)
     * @param contactId  Contact UUID
     * @param conversationId Conversation UUID (messages go here)
     * @param message    The incoming message text
     * @param flowId     chatbot_flows.id
     * @param stepIndex  Current step index (0-based)
     */
    static processFlow(db: SupabaseClient, tenantId: string, contactId: string, conversationId: string, message: string, flowId: string, stepIndex?: number): Promise<void>;
    /** Find the active keyword flow for a given message */
    static matchKeywordFlow(db: SupabaseClient, tenantId: string, message: string): Promise<string | null>;
    /** Find the first_message trigger flow for a tenant */
    static findWelcomeFlow(db: SupabaseClient, tenantId: string): Promise<string | null>;
    /** Insert an AI/system message into a conversation */
    private static sendMessage;
    /** Persist flow execution state onto the lead record */
    private static saveFlowState;
    /** Clear flow state when flow finishes or is abandoned */
    private static clearFlowState;
}
//# sourceMappingURL=flow.service.d.ts.map