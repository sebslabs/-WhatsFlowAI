/**
 * Enterprise BullMQ Queue Configuration
 *
 * Architecture:
 *  - Main queue:      whatsapp-messages  (incoming webhooks)
 *  - Outbound queue:  whatsapp-outbound  (sending messages back)
 *  - DLQ:             whatsapp-dlq       (permanently failed jobs)
 *  - Reconcile queue: reconciliation     (delivery status checks)
 *
 * Guarantees:
 *  - At-least-once delivery (via BullMQ retries)
 *  - Deduplication (jobId = Meta messageId)
 *  - DLQ for manual inspection of permanently failed jobs
 *  - Exponential backoff: 2s → 4s → 8s → 16s → 32s (max 5 attempts)
 *  - Stalled job recovery: jobs not acked within 30s are re-queued
 */
import { Queue, Worker, type WorkerOptions } from 'bullmq';
import { Redis } from 'ioredis';
export declare const QUEUE_NAMES: {
    readonly INBOUND: "whatsapp-messages";
    readonly OUTBOUND: "whatsapp-outbound";
    readonly DLQ: "whatsapp-dlq";
    readonly RECONCILE: "reconciliation";
};
export type QueueName = typeof QUEUE_NAMES[keyof typeof QUEUE_NAMES];
export declare function getRedisConnection(): Redis;
export declare function getQueue(name: QueueName): Queue;
export declare function createWorker<T>(name: QueueName, processor: (job: import('bullmq').Job<T>) => Promise<void>, opts?: Partial<WorkerOptions>): Worker<T>;
export interface DLQEntry {
    originalQueue: string;
    jobId: string | undefined;
    jobData: unknown;
    errorMessage: string;
    errorStack: string | undefined;
    attempts: number;
    failedAt: string;
}
export declare function moveToDLQ(job: import('bullmq').Job, err: Error, sourceQueue: string): Promise<void>;
export interface QueueMetrics {
    queue: string;
    waiting: number;
    active: number;
    completed: number;
    failed: number;
    delayed: number;
    paused: number;
}
export declare function getQueueMetrics(name: QueueName): Promise<QueueMetrics>;
export declare function getAllQueueMetrics(): Promise<QueueMetrics[]>;
export declare function closeAllQueues(): Promise<void>;
export { type WebhookJobData } from './queue.service.js';
export declare function enqueueInbound(data: import('./queue.service.js').WebhookJobData): Promise<string>;
export interface OutboundMessageJob {
    tenantId: string;
    phoneNumber: string;
    content: string;
    messageType: 'text' | 'image' | 'document' | 'video' | 'audio' | 'template';
    mediaUrl?: string;
    templateName?: string;
    templateParams?: string[];
    conversationId: string;
    waAccountId: string;
    idempotencyKey: string;
}
export declare function enqueueOutbound(data: OutboundMessageJob): Promise<string>;
export declare function replayDLQJob(dlqJobId: string): Promise<void>;
//# sourceMappingURL=queue.enterprise.d.ts.map