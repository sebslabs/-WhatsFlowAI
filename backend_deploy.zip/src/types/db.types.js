/**
 * ============================================================
 * WhatsFlow AI — Centralized Database Types
 * Aligned 1:1 with supabase_production_schema_final.sql v2.2
 * ============================================================
 * IMPORTANT: Do NOT add field names that don't exist in the DB.
 * This file is the single source of truth for all backend types.
 */
export {};
//# sourceMappingURL=db.types.js.map