import { createRealtimeServer } from './lib/realtime.js';
export declare const supabase: import("@supabase/supabase-js").SupabaseClient<any, "public", "public", any, any>;
declare const httpServer: import("node:http").Server<typeof import("node:http").IncomingMessage, typeof import("node:http").ServerResponse>;
export declare let io: Awaited<ReturnType<typeof createRealtimeServer>>;
export { getQueue } from './services/queue.enterprise.js';
export { httpServer };
//# sourceMappingURL=index.d.ts.map