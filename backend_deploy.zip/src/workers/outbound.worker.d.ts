/**
 * Outbound Message Worker
 *
 * Processes the `whatsapp-outbound` BullMQ queue.
 * Each job represents one message to send via Meta Cloud API.
 *
 * Guarantees:
 *  - Idempotency: idempotency_key in outbound_messages prevents double-sends on retry
 *  - At-least-once: retried up to 5x with exponential backoff
 *  - Delivery tracking: wa_message_id stored after successful send
 *  - DLQ: permanently failed sends moved to dead_letter_queue
 *  - Status reconciliation: outbound_messages.status updated on each attempt
 */
import type { OutboundMessageJob } from '../services/queue.enterprise.js';
declare const outboundWorker: import("bullmq").Worker<OutboundMessageJob, any, string>;
export declare function handleDeliveryStatusUpdate(waMessageId: string, status: 'sent' | 'delivered' | 'read' | 'failed', timestamp: string): Promise<void>;
export { outboundWorker };
//# sourceMappingURL=outbound.worker.d.ts.map