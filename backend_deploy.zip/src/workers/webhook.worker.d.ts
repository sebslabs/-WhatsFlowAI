/**
 * WebhookWorker — Corrected Production Implementation
 *
 * Processes incoming WhatsApp messages from BullMQ.
 *
 * FIXED:
 *  - whatsapp_integrations → whatsapp_accounts
 *  - messages.lead_id → messages.conversation_id
 *  - messages.sender → messages.sender_type
 *  - messages.timestamp → messages.created_at (auto)
 *  - messages.meta_message_id → messages.wa_message_id
 *  - ai_agents.status → ai_agents.is_active (boolean)
 *  - leads.current_flow_id + leads.current_step_index via migration
 *  - flows table → chatbot_flows table
 *  - organization_id → tenant_id everywhere
 *
 * Flow:
 *  1. Validate Meta signature (done in webhook.controller.ts before enqueue)
 *  2. Resolve whatsapp_accounts by phone_number_id → tenant_id
 *  3. Upsert contact by phone
 *  4. Upsert conversation for contact
 *  5. Insert inbound message with correct fields
 *  6. Log to webhook_events for idempotency
 *  7. Check if lead has active flow state → resume flow
 *  8. Match keyword flows
 *  9. Match first_message welcome flow
 *  10. Fall back to AI agent
 *  11. Emit socket.io event for realtime inbox update
 */
export {};
//# sourceMappingURL=webhook.worker.d.ts.map