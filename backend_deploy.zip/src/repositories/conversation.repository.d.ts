/**
 * Conversation Repository
 * All DB operations for `conversations` and `contacts` tables.
 * Ensures a conversation always exists before messages are inserted.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Contact, Conversation } from '../types/db.types.js';
export declare class ConversationRepository {
    private readonly db;
    constructor(db: SupabaseClient);
    /**
     * Find existing contact by phone number (tenant-scoped).
     * The unique constraint is: (tenant_id, phone)
     */
    findContactByPhone(tenantId: string, phone: string): Promise<Contact | null>;
    /**
     * Create a new contact. On conflict (tenant_id, phone), returns the existing row.
     */
    upsertContact(tenantId: string, phone: string, name?: string): Promise<Contact>;
    /**
     * Find conversation for a contact (1 contact → 1 conversation per tenant, enforced by unique constraint).
     */
    findByContact(tenantId: string, contactId: string): Promise<Conversation | null>;
    /**
     * Create a conversation for a contact.
     * On conflict (tenant_id, contact_id) returns the existing row.
     */
    upsertConversation(tenantId: string, contactId: string): Promise<Conversation>;
    /**
     * Touch last_message_at and increment unread_count atomically.
     */
    touchLastMessage(conversationId: string): Promise<void>;
    /**
     * Switch conversation mode (ai → manual on human handover).
     */
    setMode(tenantId: string, conversationId: string, mode: 'ai' | 'manual' | 'flow'): Promise<void>;
}
//# sourceMappingURL=conversation.repository.d.ts.map