export class MessageRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    /**
     * Insert a new message. If wa_message_id is present, duplicate inserts
     * are silently ignored via the UNIQUE constraint.
     */
    async insert(dto) {
        const { data, error } = await this.db
            .from('messages')
            .insert({
            tenant_id: dto.tenant_id,
            conversation_id: dto.conversation_id,
            sender_type: dto.sender_type,
            content: dto.content,
            message_type: dto.message_type ?? 'text',
            media_url: dto.media_url ?? null,
            wa_message_id: dto.wa_message_id ?? null,
        })
            .select()
            .single();
        // 23505 = unique_violation — duplicate wa_message_id, safe to ignore
        if (error) {
            if (error.code === '23505')
                return null;
            throw new Error(`[MessageRepository.insert] ${error.message}`);
        }
        return data;
    }
    /** Fetch messages for a conversation, ordered chronologically. */
    async findByConversation(conversationId, limit = 50) {
        const { data, error } = await this.db
            .from('messages')
            .select('*')
            .eq('conversation_id', conversationId)
            .order('created_at', { ascending: true })
            .limit(limit);
        if (error)
            throw new Error(`[MessageRepository.findByConversation] ${error.message}`);
        return (data ?? []);
    }
    /** Update delivery status for a sent message. */
    async updateDeliveryStatus(waMessageId, status) {
        const { error } = await this.db
            .from('messages')
            .update({ delivery_status: status })
            .eq('wa_message_id', waMessageId);
        if (error)
            throw new Error(`[MessageRepository.updateDeliveryStatus] ${error.message}`);
    }
}
//# sourceMappingURL=message.repository.js.map