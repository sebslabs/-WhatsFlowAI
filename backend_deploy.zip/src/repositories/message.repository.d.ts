/**
 * Message Repository
 * All DB operations for `messages` table.
 * Uses correct schema field names (conversation_id, sender_type, wa_message_id, created_at).
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Message, MsgSenderType } from '../types/db.types.js';
export interface InsertMessageDTO {
    tenant_id: string;
    conversation_id: string;
    sender_type: MsgSenderType;
    content: string;
    message_type?: string;
    media_url?: string;
    wa_message_id?: string;
}
export declare class MessageRepository {
    private readonly db;
    constructor(db: SupabaseClient);
    /**
     * Insert a new message. If wa_message_id is present, duplicate inserts
     * are silently ignored via the UNIQUE constraint.
     */
    insert(dto: InsertMessageDTO): Promise<Message | null>;
    /** Fetch messages for a conversation, ordered chronologically. */
    findByConversation(conversationId: string, limit?: number): Promise<Message[]>;
    /** Update delivery status for a sent message. */
    updateDeliveryStatus(waMessageId: string, status: 'delivered' | 'read' | 'failed'): Promise<void>;
}
//# sourceMappingURL=message.repository.d.ts.map