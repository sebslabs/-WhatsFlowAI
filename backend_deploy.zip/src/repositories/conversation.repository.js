export class ConversationRepository {
    db;
    constructor(db) {
        this.db = db;
    }
    /**
     * Find existing contact by phone number (tenant-scoped).
     * The unique constraint is: (tenant_id, phone)
     */
    async findContactByPhone(tenantId, phone) {
        const { data, error } = await this.db
            .from('contacts')
            .select('*')
            .eq('tenant_id', tenantId)
            .eq('phone', phone)
            .maybeSingle();
        if (error)
            throw new Error(`[ConversationRepository.findContactByPhone] ${error.message}`);
        return data;
    }
    /**
     * Create a new contact. On conflict (tenant_id, phone), returns the existing row.
     */
    async upsertContact(tenantId, phone, name = 'New Contact') {
        const { data, error } = await this.db
            .from('contacts')
            .upsert({ tenant_id: tenantId, phone, name }, { onConflict: 'tenant_id,phone', ignoreDuplicates: false })
            .select()
            .single();
        if (error)
            throw new Error(`[ConversationRepository.upsertContact] ${error.message}`);
        return data;
    }
    /**
     * Find conversation for a contact (1 contact → 1 conversation per tenant, enforced by unique constraint).
     */
    async findByContact(tenantId, contactId) {
        const { data, error } = await this.db
            .from('conversations')
            .select('*')
            .eq('tenant_id', tenantId)
            .eq('contact_id', contactId)
            .maybeSingle();
        if (error)
            throw new Error(`[ConversationRepository.findByContact] ${error.message}`);
        return data;
    }
    /**
     * Create a conversation for a contact.
     * On conflict (tenant_id, contact_id) returns the existing row.
     */
    async upsertConversation(tenantId, contactId) {
        const { data, error } = await this.db
            .from('conversations')
            .upsert({
            tenant_id: tenantId,
            contact_id: contactId,
            status: 'open',
            mode: 'ai',
        }, { onConflict: 'tenant_id,contact_id', ignoreDuplicates: false })
            .select()
            .single();
        if (error)
            throw new Error(`[ConversationRepository.upsertConversation] ${error.message}`);
        return data;
    }
    /**
     * Touch last_message_at and increment unread_count atomically.
     */
    async touchLastMessage(conversationId) {
        const { error } = await this.db.rpc('increment_unread_and_touch', {
            p_conversation_id: conversationId,
        });
        // If RPC doesn't exist yet, fall back to explicit update
        if (error) {
            await this.db
                .from('conversations')
                .update({ last_message_at: new Date().toISOString() })
                .eq('id', conversationId);
        }
    }
    /**
     * Switch conversation mode (ai → manual on human handover).
     */
    async setMode(tenantId, conversationId, mode) {
        const { error } = await this.db
            .from('conversations')
            .update({ mode })
            .eq('id', conversationId)
            .eq('tenant_id', tenantId);
        if (error)
            throw new Error(`[ConversationRepository.setMode] ${error.message}`);
    }
}
//# sourceMappingURL=conversation.repository.js.map