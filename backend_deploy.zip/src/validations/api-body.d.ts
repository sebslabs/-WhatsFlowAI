import { z } from 'zod';
/** Campaign save payload (whitelist — prevents mass assignment) */
export declare const saveCampaignBodySchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    status: z.ZodOptional<z.ZodEnum<{
        failed: "failed";
        sent: "sent";
        draft: "draft";
        scheduled: "scheduled";
    }>>;
    audienceType: z.ZodOptional<z.ZodString>;
    audienceTag: z.ZodOptional<z.ZodString>;
    audienceCount: z.ZodOptional<z.ZodNumber>;
    message: z.ZodOptional<z.ZodString>;
    mediaType: z.ZodOptional<z.ZodString>;
    mediaUrl: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
    scheduledAt: z.ZodOptional<z.ZodString>;
    sentAt: z.ZodOptional<z.ZodString>;
    stats: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    createdAt: z.ZodOptional<z.ZodString>;
    buttons: z.ZodOptional<z.ZodArray<z.ZodUnknown>>;
}, z.core.$strip>;
export declare const saveFlowBodySchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    active: z.ZodOptional<z.ZodBoolean>;
    triggerType: z.ZodEnum<{
        tag: "tag";
        first_message: "first_message";
        keyword: "keyword";
        manual: "manual";
    }>;
    triggerKeyword: z.ZodOptional<z.ZodString>;
    steps: z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        message: z.ZodOptional<z.ZodString>;
        variableName: z.ZodOptional<z.ZodString>;
        buttons: z.ZodOptional<z.ZodArray<z.ZodUnknown>>;
        tagName: z.ZodOptional<z.ZodString>;
        notifyNote: z.ZodOptional<z.ZodString>;
        bookingUrl: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodLiteral<"">]>>;
        delayMinutes: z.ZodOptional<z.ZodNumber>;
        conditionVariable: z.ZodOptional<z.ZodString>;
        conditionOperator: z.ZodOptional<z.ZodString>;
        conditionValue: z.ZodOptional<z.ZodString>;
        mediaType: z.ZodOptional<z.ZodString>;
        mediaUrl: z.ZodOptional<z.ZodString>;
        aiPrompt: z.ZodOptional<z.ZodString>;
        webhookUrl: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodLiteral<"">]>>;
        listTitle: z.ZodOptional<z.ZodString>;
        listItems: z.ZodOptional<z.ZodArray<z.ZodUnknown>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const createTicketBodySchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    priority: z.ZodOptional<z.ZodEnum<{
        low: "low";
        medium: "medium";
        high: "high";
        urgent: "urgent";
    }>>;
    category: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const updateSettingsBodySchema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
export declare const saveWhatsAppTemplateBodySchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    language: z.ZodOptional<z.ZodString>;
    category: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodString>;
    components: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    created_at: z.ZodOptional<z.ZodString>;
    updated_at: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const createCatalogProductBodySchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    price: z.ZodNumber;
    compare_price: z.ZodOptional<z.ZodNumber>;
    sku: z.ZodOptional<z.ZodString>;
    category: z.ZodOptional<z.ZodString>;
    stock: z.ZodOptional<z.ZodNumber>;
    image_url: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        active: "active";
        draft: "draft";
        inactive: "inactive";
    }>>;
}, z.core.$strip>;
export declare const updateCatalogProductBodySchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    price: z.ZodOptional<z.ZodNumber>;
    compare_price: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    sku: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    category: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    stock: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    image_url: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    status: z.ZodOptional<z.ZodOptional<z.ZodEnum<{
        active: "active";
        draft: "draft";
        inactive: "inactive";
    }>>>;
}, z.core.$strip>;
export declare const createAIAgentBodySchema: z.ZodObject<{
    name: z.ZodString;
    role: z.ZodString;
    instructions: z.ZodString;
    tone: z.ZodEnum<{
        professional: "professional";
        friendly: "friendly";
        formal: "formal";
        casual: "casual";
        empathetic: "empathetic";
    }>;
}, z.core.$strip>;
export declare const updateAIAgentBodySchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    role: z.ZodOptional<z.ZodString>;
    instructions: z.ZodOptional<z.ZodString>;
    tone: z.ZodOptional<z.ZodEnum<{
        professional: "professional";
        friendly: "friendly";
        formal: "formal";
        casual: "casual";
        empathetic: "empathetic";
    }>>;
}, z.core.$strip>;
export declare const chatWithAIAgentBodySchema: z.ZodObject<{
    message: z.ZodString;
    history: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodObject<{
        role: z.ZodEnum<{
            user: "user";
            assistant: "assistant";
        }>;
        content: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>;
export declare const toggleAIAgentStatusBodySchema: z.ZodObject<{
    status: z.ZodEnum<{
        active: "active";
        paused: "paused";
        inactive: "inactive";
    }>;
}, z.core.$strip>;
export declare const idParamSchema: z.ZodObject<{
    id: z.ZodString;
}, z.core.$strip>;
export declare const leadIdParamSchema: z.ZodObject<{
    leadId: z.ZodString;
}, z.core.$strip>;
//# sourceMappingURL=api-body.d.ts.map